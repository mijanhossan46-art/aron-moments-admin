import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'user_gate.dart';
import 'admin_panel.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const AronMomentsApp());
}

class AronMomentsApp extends StatelessWidget {
  const AronMomentsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Aron Moments',
      theme: ThemeData(useMaterial3: true),
      routes: {
        '/': (_) => const UserGate(),
        '/admin': (_) => const AdminPanel(),
      },
    );
  }
}
