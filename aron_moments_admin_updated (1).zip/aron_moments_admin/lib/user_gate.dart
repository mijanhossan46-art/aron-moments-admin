import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class UserGate extends StatefulWidget {
  const UserGate({super.key});

  @override
  State<UserGate> createState() => _UserGateState();
}

class _UserGateState extends State<UserGate> {
  String status = 'Checking...';

  @override
  void initState() {
    super.initState();
    _check();
  }

  Future<void> _check() async {
    final auth = FirebaseAuth.instance;
    final user = auth.currentUser ?? (await auth.signInAnonymously()).user!;
    final ref = FirebaseFirestore.instance.collection('users').doc(user.uid);
    final snap = await ref.get();

    if (!snap.exists) {
      await ref.set({
        'status': 'pending',
        'createdAt': FieldValue.serverTimestamp(),
      });
      setState(() => status = 'Pending admin approval');
      return;
    }

    final data = snap.data()!;
    final value = data['status'];
    setState(() {
      status = value == 'approved'
          ? 'Approved — access allowed'
          : value == 'blocked'
              ? 'Blocked by admin'
              : 'Pending admin approval';
    });
  }

  @override
  Widget build(BuildContext context) {
    final approved = status.startsWith('Approved');
    return Scaffold(
      appBar: AppBar(title: const Text('Aron Moments')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(status, textAlign: TextAlign.center),
            const SizedBox(height: 20),
            if (approved)
              const Text('Home screen can be placed here.'),
            TextButton(
              onPressed: _check,
              child: const Text('Check again'),
            ),
            TextButton(
              onPressed: () => Navigator.pushNamed(context, '/admin'),
              child: const Text('Admin panel (secure this in production)'),
            ),
          ],
        ),
      ),
    );
  }
}
