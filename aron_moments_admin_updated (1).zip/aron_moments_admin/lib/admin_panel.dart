import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class AdminPanel extends StatelessWidget {
  const AdminPanel({super.key});

  Future<void> _setStatus(String uid, String status) {
    return FirebaseFirestore.instance.collection('users').doc(uid).update({
      'status': status,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  @override
  Widget build(BuildContext context) {
    final stream = FirebaseFirestore.instance.collection('users').snapshots();
    return Scaffold(
      appBar: AppBar(title: const Text('Admin Panel')),
      body: StreamBuilder<QuerySnapshot>(
        stream: stream,
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final docs = snapshot.data!.docs;
          if (docs.isEmpty) {
            return const Center(child: Text('No users yet'));
          }
          return ListView.builder(
            itemCount: docs.length,
            itemBuilder: (_, i) {
              final d = docs[i];
              final data = d.data() as Map<String, dynamic>;
              final status = data['status'] ?? 'pending';
              return ListTile(
                title: Text(d.id),
                subtitle: Text('Status: $status'),
                trailing: Wrap(
                  children: [
                    IconButton(
                      tooltip: 'Approve',
                      onPressed: () => _setStatus(d.id, 'approved'),
                      icon: const Icon(Icons.check),
                    ),
                    IconButton(
                      tooltip: 'Block',
                      onPressed: () => _setStatus(d.id, 'blocked'),
                      icon: const Icon(Icons.block),
                    ),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }
}
