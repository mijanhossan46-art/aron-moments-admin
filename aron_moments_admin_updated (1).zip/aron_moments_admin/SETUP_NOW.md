1. In Firebase Console enable Authentication -> Anonymous (for this starter).
2. Create Firestore Database.
3. Deploy firestore/firestore.rules.
4. For production, create a real admin login and set the Firebase admin custom claim
   through a trusted backend/Cloud Function.
5. Build with Flutter on a computer/Android build environment.
