package com.example.aron_moments_admin

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
