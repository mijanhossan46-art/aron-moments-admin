# Aron Moments — Admin Approval Starter

Firebase project:
- project_id: aron-momemts
- Android package: com.aktcl.ecrm.br

This is a starter/source project for a new approval flow. It is NOT a rebuilt version
of the original APK and it does not bypass the original app's authentication.

## Intended flow
App -> create pending user -> admin approves -> status becomes approved -> access allowed.

## Important
The sample Admin Panel is intentionally not production-secure by itself. Before deployment,
configure Firebase Authentication for admins and grant an `admin` custom claim from a
trusted backend/Cloud Function. Do not let ordinary users write their own status.

## Build
On a computer with Flutter/Android SDK:
1. flutter pub get
2. flutter build apk --release

The uploaded google-services.json is already placed at:
android/app/google-services.json
